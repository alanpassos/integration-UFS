
class Vertex
   {
	
	public char label;
	public boolean wasVisited;
	int pai;

   public Vertex(char lab) 
      {
      label = lab;
      wasVisited = false;
      pai =  -1 ;
      }
   
   }
