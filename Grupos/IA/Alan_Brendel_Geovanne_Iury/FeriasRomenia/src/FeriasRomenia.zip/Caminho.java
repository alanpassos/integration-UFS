
public class Caminho {
	int custoCaminho;
	int pai;
	public Caminho(int custoCaminho, int pai) {
		this.custoCaminho = custoCaminho;
		this.pai = pai;
	}
	
}
